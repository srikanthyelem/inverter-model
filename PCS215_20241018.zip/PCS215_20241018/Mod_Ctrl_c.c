/* ========================================================================== */
/*                                                                            */
/*   controller.c                                                             */
/*   (c) 2012 Author   Jiao Liu                                               */
/*                                                                            */
/*   Description                                                              */
/*   The wapper of the controller for PSCAD simulation                        */
/* ========================================================================== */

#pragma comment(lib,"../lib/PCS_Ctrl_Mod.lib")

double mod_input[47]  = {0};
double mod_output[55] = {0};

void PCS_Ctrl_Mod(double *input, double *output);
//void PCS_Ctrl_DSP(double *input, double *output);

void module_controller(double *SimTime,
			double *SimTmStep,
			double *Vdc_Bus,
			double *Vcap_ll,
			double *Vgm_ll,
			double *Idc,
			double *IL11_phs,
			double *IL12_phs,
			double *IL2_phs,
			double *Emif_fromSys, 
			double *GC_VOLT_PROTECTION,
			double *GC_FREQ_PROTECTION,
			double *ModSimTmr,
			double *ModScope,
			double *PWM_Enb, 
			double *Duty1_ABC,
			double *Duty2_ABC, 
			double *Emif_toSys)
{
	int j = 0;
	int k = 0;
	
	mod_input[0]  = *SimTime;
	mod_input[1]  = *SimTmStep;
	mod_input[2]  = Vdc_Bus[0];
	mod_input[3]  = Vdc_Bus[1];
	mod_input[4]  = Vdc_Bus[2];
	mod_input[5]  = Vcap_ll[0];
	mod_input[6]  = Vcap_ll[1];
	mod_input[7]  = Vgm_ll[0];
	mod_input[8]  = Vgm_ll[1];
	mod_input[9]  = *Idc;
	mod_input[10] = IL11_phs[0];
	mod_input[11] = IL11_phs[1];
	mod_input[12] = IL11_phs[2];
	mod_input[13] = IL12_phs[0];
	mod_input[14] = IL12_phs[1];
	mod_input[15] = IL12_phs[2];
	mod_input[16] = IL2_phs[0];
	mod_input[17] = IL2_phs[1];
	mod_input[18] = IL2_phs[2];
	mod_input[19] = Emif_fromSys[0];
	mod_input[20] = Emif_fromSys[1];
	mod_input[21] = Emif_fromSys[2];
	mod_input[22] = Emif_fromSys[3];
	mod_input[23] = Emif_fromSys[4];
	mod_input[24] = Emif_fromSys[5];

	for(j=25;j<37;j++)
	{
		mod_input[j] = GC_VOLT_PROTECTION[k];
		k++;
	}
	k = 0;

	for(j=37;j<47;j++)
	{
		mod_input[j] = GC_FREQ_PROTECTION[k];
		k++;
	}
	k = 0;


	PCS_Ctrl_Mod(mod_input, mod_output);
	//PCS_Ctrl_DSP(mod_input, mod_output);

	*ModSimTmr = mod_output[0];

	for(j=1;j<41;j++)
	{
		ModScope[k]   = mod_output[j];
		k++;
	}
	k = 0;

	*PWM_Enb = mod_output[41];
	
	Duty1_ABC[0] = mod_output[42];
	Duty1_ABC[1] = mod_output[43];
	Duty1_ABC[2] = mod_output[44];
	Duty2_ABC[0] = mod_output[45];
	Duty2_ABC[1] = mod_output[46];
	Duty2_ABC[2] = mod_output[47];


       
       Emif_toSys[0] = mod_output[48];
	Emif_toSys[1] = mod_output[49];
	Emif_toSys[2] = mod_output[50];
	Emif_toSys[3] = mod_output[51];	
       Emif_toSys[4] = mod_output[52];	
	Emif_toSys[5] = mod_output[53];	
       Emif_toSys[6] = mod_output[54];
}





































































































































