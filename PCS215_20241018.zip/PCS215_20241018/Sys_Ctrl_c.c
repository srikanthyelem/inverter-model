/* ========================================================================== */
/*                                                                            */
/*   controller.c                                                             */
/*   (c) 2012 Author   Jiao Liu                                               */
/*                                                                            */
/*   Description                                                              */
/*   The wapper of the controller for PSCAD simulation                        */
/* ========================================================================== */

#pragma comment(lib,"../lib/PCS_Ctrl_Sys.lib")

double sys_input[98]  = {0};
double sys_output[47] = {0};

void PCS_Ctrl_Sys(double *input, double *output);
//void PCS_Ctrl_ARM(double *input, double *output);

void local_controller(double *SimTime,
			double *SimTmStep,
			double *PowerRef,
			double *VarRef,
			double *Vdc_In,
			double *Idc_In,
			double *Vgrid_ll,
			double *Igrid_phs,
			double *Emif_fromMod,
			double *GC_Q_MODE_SEL,
			double *GC_PQ_PRIORITY,
			double *GC_ANTI_ISLANDING_EN,
			double *GC_VOLT_PROTECTION,
			double *GC_FREQ_PROTECTION,
			double *GC_SPF_CTRL,
			double *GC_VOLT_VAR_CTRL,
			double *GC_VOLT_WATT_CTRL,
			double *GC_FREQ_WATT_CTRL_1,
			double *GC_FREQ_WATT_CTRL_2,
			double *GC_VOLT_RIDE_THROUGH,
			double *SysSimTmr,
			double *SysScope,
			double *Emif_toMod)
{
	int i = 0;
	int j = 0;
	int k = 0;
	
	sys_input[0]  = *SimTime;
	sys_input[1]  = *SimTmStep;
	sys_input[2]  = *PowerRef;
	sys_input[3]  = *VarRef;
	sys_input[4]  = *Vdc_In;
	sys_input[5]  = *Idc_In;
	sys_input[6]  = Vgrid_ll[0];
	sys_input[7]  = Vgrid_ll[1];
	sys_input[8]  = Igrid_phs[0];
	sys_input[9]  = Igrid_phs[1];
	sys_input[10] = Igrid_phs[2];
	sys_input[11] = Emif_fromMod[0];
	sys_input[12] = Emif_fromMod[1];
	sys_input[13] = Emif_fromMod[2];
	sys_input[14] = Emif_fromMod[3];
	sys_input[15] = Emif_fromMod[4];
	sys_input[16] = Emif_fromMod[5];
	sys_input[17] = Emif_fromMod[6];
	sys_input[18] = *GC_Q_MODE_SEL;
	sys_input[19] = *GC_PQ_PRIORITY;
	sys_input[20] = *GC_ANTI_ISLANDING_EN;

	for(i=21;i<33;i++)
	{
		sys_input[i] = GC_VOLT_PROTECTION[k];
		k++;
	}
	k = 0;
	
	for(i=33;i<43;i++)
	{
		sys_input[i] = GC_FREQ_PROTECTION[k];
		k++;
	}
	k = 0;

	for(i=43;i<51;i++)
	{
		sys_input[i] = GC_SPF_CTRL[k];
		k++;
	}
	k = 0;

	for(i=51;i<61;i++)
	{
		sys_input[i] = GC_VOLT_VAR_CTRL[k];
		k++;
	}
	k = 0;

	for(i=61;i<71;i++)
	{
		sys_input[i] = GC_VOLT_WATT_CTRL[k];
		k++;
	}
	k = 0;

	for(i=71;i<82;i++)
	{
		sys_input[i] = GC_FREQ_WATT_CTRL_1[k];
		k++;
	}
	k = 0;

	for(i=82;i<91;i++)
	{
		sys_input[i] = GC_FREQ_WATT_CTRL_2[k];
		k++;
	}
	k = 0;

	for(i=91;i<98;i++)
	{
		sys_input[i] = GC_VOLT_RIDE_THROUGH[k];
		k++;
	}
	k = 0;

	PCS_Ctrl_Sys(sys_input, sys_output);
	//PCS_Ctrl_ARM(arm_input, arm_output);

	*SysSimTmr = sys_output[0];

	for(j=1;j<41;j++)
	{
		SysScope[k]   = sys_output[j];
		k++;
	}
	k = 0;
	
	Emif_toMod[0] = sys_output[41];
	Emif_toMod[1] = sys_output[42];
	Emif_toMod[2] = sys_output[43];
	Emif_toMod[3] = sys_output[44];
	Emif_toMod[4] = sys_output[45];
	Emif_toMod[5] = sys_output[46];
}



























































































































































