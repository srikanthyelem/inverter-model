subroutine duty_limiter_fsub(enable,mod_in,lf_up,lf_dn,hf_up,hf_dn)
include "s1.h"
!
	REAL enable,mod_in,lf_up,lf_dn,hf_up,hf_dn
!
	if(enable < 0.5) then	
		lf_up = 0
		lf_dn = 0
		hf_up = 0
		hf_dn = 0
	else if(mod_in > 0) then
		lf_up = 1
		lf_dn = 0
!
		if(mod_in >= 1) then
			hf_up = 1
			hf_dn = 0
		else
			hf_up = mod_in
			hf_dn = 1-mod_in
		end if
!
	else
		lf_up = 0
		lf_dn = 1
!
		if(mod_in <= -1) then
			hf_up = 0
			hf_dn = 1
		else
			hf_up = 1 + mod_in
			hf_dn = -mod_in
		end if
!
	end if	



end subroutine duty_limiter_fsub




























































