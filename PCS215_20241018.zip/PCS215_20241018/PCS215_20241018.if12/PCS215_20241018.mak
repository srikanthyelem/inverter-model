
#------------------------------------------------------------------------------
# Project 'PCS215_20241018' make using the 'Intel(R) Visual Fortran Compiler XE 14.0.1.139' compiler.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# All project
#------------------------------------------------------------------------------

all: targets
	@echo !--Make: succeeded.



#------------------------------------------------------------------------------
# Directories, Platform, and Version
#------------------------------------------------------------------------------

Arch        = windows
EmtdcDir    = C:\Program Files (x86)\PSCAD502 x64\emtdc\if12
EmtdcInc    = $(EmtdcDir)\inc
EmtdcBin    = $(EmtdcDir)\$(Arch)
EmtdcMain   = $(EmtdcBin)\main.obj
EmtdcLib    = $(EmtdcBin)\emtdc.lib
SolverLib    = $(EmtdcBin)\Solver.lib


#------------------------------------------------------------------------------
# Fortran Compiler
#------------------------------------------------------------------------------

FC_Name         = ifort.exe
FC_Suffix       = obj
FC_Args         = /nologo /c /free /real_size:64 /fpconstant /warn:declarations /iface:default /align:dcommons /fpe:0
FC_Debug        =  /O2
FC_Preprocess   = 
FC_Preproswitch = 
FC_Warn         = 
FC_Checks       = 
FC_Includes     = /include:"$(EmtdcInc)" /include:"$(EmtdcDir)" /include:"$(EmtdcBin)"
FC_Compile      = $(FC_Name) $(FC_Args) $(FC_Includes) $(FC_Debug) $(FC_Warn) $(FC_Checks)

#------------------------------------------------------------------------------
# C Compiler
#------------------------------------------------------------------------------

CC_Name     = cl.exe
CC_Suffix   = obj
CC_Args     = /nologo /MT /W3 /EHsc /c
CC_Debug    =  /O2
CC_Includes = 
CC_Compile  = $(CC_Name) $(CC_Args) $(CC_Includes) $(CC_Debug)

#------------------------------------------------------------------------------
# Linker
#------------------------------------------------------------------------------

Link_Name   = link.exe
Link_Debug  = 
Link_Args   = /out:$@ /nologo /nodefaultlib:libc.lib /nodefaultlib:libcmtd.lib /subsystem:console
Link        = $(Link_Name) $(Link_Args) $(Link_Debug)

#------------------------------------------------------------------------------
# Build rules for generated files
#------------------------------------------------------------------------------


.f.$(FC_Suffix):
	@echo !--Compile: $<
	$(FC_Compile) $<



.c.$(CC_Suffix):
	@echo !--Compile: $<
	$(CC_Compile) $<



#------------------------------------------------------------------------------
# Build rules for file references
#------------------------------------------------------------------------------


Mod_Ctrl_f_F1.$(FC_Suffix): 
	@echo !--Compile: "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Mod_Ctrl_f.f"
	$(FC_Compile) "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Mod_Ctrl_f.f" -o Mod_Ctrl_f_F1.$(FC_Suffix)

Sys_Ctrl_f_F2.$(FC_Suffix): 
	@echo !--Compile: "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Sys_Ctrl_f.f"
	$(FC_Compile) "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Sys_Ctrl_f.f" -o Sys_Ctrl_f_F2.$(FC_Suffix)

Duty_Limiter_f_F3.$(FC_Suffix): 
	@echo !--Compile: "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Duty_Limiter_f.f"
	$(FC_Compile) "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Duty_Limiter_f.f" -o Duty_Limiter_f_F3.$(FC_Suffix)

Mod_Ctrl_c_C1.$(CC_Suffix): 
	@echo !--Compile: "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Mod_Ctrl_c.c"
	$(CC_Compile) "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Mod_Ctrl_c.c" /FoMod_Ctrl_c_C1.$(CC_Suffix)

Sys_Ctrl_c_C2.$(CC_Suffix): 
	@echo !--Compile: "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Sys_Ctrl_c.c"
	$(CC_Compile) "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\Sys_Ctrl_c.c" /FoSys_Ctrl_c_C2.$(CC_Suffix)

PCS_Ctrl_Mod_1.lib: 
	@echo !--Copy: "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\lib\PCS_Ctrl_Mod.lib"
	copy "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\lib\PCS_Ctrl_Mod.lib" "PCS_Ctrl_Mod_1.lib"

PCS_Ctrl_Sys_2.lib: 
	@echo !--Copy: "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\lib\PCS_Ctrl_Sys.lib"
	copy "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\lib\PCS_Ctrl_Sys.lib" "PCS_Ctrl_Sys_2.lib"

#------------------------------------------------------------------------------
# Dependencies
#------------------------------------------------------------------------------


FC_Objects = \
 Station.$(FC_Suffix) \
 Main.$(FC_Suffix) \
 BESS_Module.$(FC_Suffix) \
 PCS215kW.$(FC_Suffix) \
 ThreePhasIndFilter.$(FC_Suffix) \
 ThreePhaseCapFilter.$(FC_Suffix) \
 ADC_Sampling_Circuit.$(FC_Suffix) \
 CBC_Curr_Ctrl_PWM.$(FC_Suffix) \
 PWM_Gen_3Phs_ANPC_IntPlt.$(FC_Suffix) \
 PWM_Gen_1Phs_ANPC_IntPlt.$(FC_Suffix) \
 ANPC_3L_3Phs_Brg_IntPlt.$(FC_Suffix) \
 Mod_Ctrl_f_F1.$(FC_Suffix) \
 Sys_Ctrl_f_F2.$(FC_Suffix) \
 Duty_Limiter_f_F3.$(FC_Suffix)

FC_ObjectsLong = \
 "Station.$(FC_Suffix)" \
 "Main.$(FC_Suffix)" \
 "BESS_Module.$(FC_Suffix)" \
 "PCS215kW.$(FC_Suffix)" \
 "ThreePhasIndFilter.$(FC_Suffix)" \
 "ThreePhaseCapFilter.$(FC_Suffix)" \
 "ADC_Sampling_Circuit.$(FC_Suffix)" \
 "CBC_Curr_Ctrl_PWM.$(FC_Suffix)" \
 "PWM_Gen_3Phs_ANPC_IntPlt.$(FC_Suffix)" \
 "PWM_Gen_1Phs_ANPC_IntPlt.$(FC_Suffix)" \
 "ANPC_3L_3Phs_Brg_IntPlt.$(FC_Suffix)" \
 "Mod_Ctrl_f_F1.$(FC_Suffix)" \
 "Sys_Ctrl_f_F2.$(FC_Suffix)" \
 "Duty_Limiter_f_F3.$(FC_Suffix)"

CC_Objects = \
  Mod_Ctrl_c_C1.$(CC_Suffix) \
  Sys_Ctrl_c_C2.$(CC_Suffix)

CC_ObjectsLong = \
  "Mod_Ctrl_c_C1.$(CC_Suffix)" \
  "Sys_Ctrl_c_C2.$(CC_Suffix)"

LK_Objects = \
  PCS_Ctrl_Mod_1.lib \
  PCS_Ctrl_Sys_2.lib

LK_ObjectsLong = \
  "PCS_Ctrl_Mod_1.lib" \
  "PCS_Ctrl_Sys_2.lib"

SysLibs  = wsock32.lib

Binary   = PCS215_20241018.exe

$(Binary): $(FC_Objects) $(CC_Objects) $(LK_Objects) 
	@echo !--Link: $@
	$(Link) "$(EmtdcMain)" $(FC_ObjectsLong) $(CC_ObjectsLong) $(LK_ObjectsLong) "$(EmtdcLib)" "$(SolverLib)" $(SysLibs)

targets: $(Binary)


clean:
	-del EMTDC_V*
	-del *.obj
	-del *.o
	-del *.exe
	@echo !--Make clean: succeeded.



