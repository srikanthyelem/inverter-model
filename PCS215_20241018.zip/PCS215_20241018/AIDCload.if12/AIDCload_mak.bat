call "C:\Program Files (x86)\Intel\Composer XE 2013 SP1\bin\ifortvars.bat"  ia32
pushd "C:\PCS4300_PSCAD model\PCS215_PSCAD_Model_20241021_SW\PCS215_20241018\AIDCload.if12\"
nmake -f AIDCload.mak
popd
